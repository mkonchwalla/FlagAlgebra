from main import *

"""
Generating H's
"""

def subcube_edge_density(G,n):
    return len(G.Edges)/(n*2**(n-1))

def subcube_two_flag_density(F_i,F_j,G,theta):  
    """
    F_i , F_j - Flags of the same size and with the same type and they fit in G.
    G - Graph 
    Theta – which maps the labelled vertices of F to G
    Assuming s=1
    """
    k_1=len(F_i)
    k_2 = len(F_j)
    s=len(F_i.sigma)
    G_flag = Flag( V=G.Verticies , E = G.Edges, sigma = theta)
    print(G_flag.degrees())
    c=0 # the counter 
    total=0
    for k_tup in itertools.permutations(G_v,k_1 + k_2- 2*s):
        total+=1
        H1=induced_subgraph(list(G_flag.labelled_verticies.values())+list(k_tup)[:k_1 - s],G_flag)
        H2=induced_subgraph(list(G_flag.labelled_verticies.values())+list(k_tup)[k_1 - s:],G_flag)
        if isFlagIsomorphic(F_i,H1) and isFlagIsomorphic(F_j, H2):
            c+=1 
    return c/total

def subcube_E_theta(F_i,F_j,G): 
    labels=list(F_i.sigma.keys())
    s= len(labels)
    n=len(G)
    E_value=0
    for vertices in itertools.permutations(G.Verticies,s):
        theta=dict(zip(labels,list(vertices)))
        E_value+= two_flag_density(F_i,F_j,G,theta)
    return E_value / nPk(n,s)


C4=generate_cycle_graph(4)
cube=generate_hyper_cube(3)
Graphs=[]
with open('hc.txt','r') as f:
        for line in f:
            V=[Vertex(name=''.join([str(y) for y in x])) for x in itertools.product([0,1],repeat=3)]
            G=Graph(V)
            l=line.strip('\n').replace('000','"000"').replace('001','"001"').replace('010','"010"').replace('100','"100"').replace('011','"011"').replace('110','"110"').replace('101','"101"').replace('111','"111"')
            l=eval(l)
            dc=dict(zip([''.join([str(y) for y in x]) for x in itertools.product([0,1],repeat=3)],V))
            if l!=[]:
                for e in l:
                    G.add_edge(dc[e[0]],dc[e[1]])
            if not G.contains_copy(C4):
                Graphs.append(G)

print(len(Graphs))

"""
Generating Flags
"""
"""
Creating Flags 
"""
# V = [Vertex(name="v"+str(i)) for i in range(1,4)]
# f1 = Graph(V)
# sigma=dict([ ("ab"[i],f1.Verticies[i]) for i in range(1)])
# f1=Flag(f1.Verticies,f1.Edges,sigma)
# print(f1.Verticies,f1.Edges)
# f2 = generate_complete_graph(2)
# sigma=dict([ ("ab"[i],f2.Verticies[i]) for i in range(1)])
# f2=Flag(f2.Verticies,f2.Edges,sigma)
# print(f2.Verticies,f2.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
f1 = Graph(V)
f1.add_edge(f1.Verticies[0] , f1.Verticies[1])
sigma=dict([ ("12"[i],f1.Verticies[i]) for i in range(2)])
f1=Flag(f1.Verticies,f1.Edges,sigma)
print(f1.Verticies,f1.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
f2 = Graph(V)
f2.add_edge(f2.Verticies[0] , f2.Verticies[1])
f2.add_edge(f2.Verticies[1] , f2.Verticies[2])
sigma=dict([ ("12"[i],f2.Verticies[i]) for i in range(2)])
f2=Flag(f2.Verticies,f2.Edges,sigma)
print(f2.Verticies,f2.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
f3 = Graph(V)
f3.add_edge(f3.Verticies[0] , f3.Verticies[1])
f3.add_edge(f3.Verticies[0] , f3.Verticies[2])
sigma=dict([ ("12"[i],f3.Verticies[i]) for i in range(2)])
f3=Flag(f3.Verticies,f3.Edges,sigma)
print(f3.Verticies,f3.Edges)

f4 = generate_complete_graph(3)
sigma=dict([ ("12"[i],f4.Verticies[i]) for i in range(2)])
f4=Flag(f4.Verticies,f4.Edges,sigma)
print(f4.Verticies,f4.Edges)


V = [Vertex(name="v"+str(i)) for i in range(1,4)]
y1 = Graph(V)
sigma=dict([ ("12"[i],y1.Verticies[i]) for i in range(2)])
y1=Flag(y1.Verticies,y1.Edges,sigma)
print(y1.Verticies,y1.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
y2 = Graph(V)
y2.add_edge(y2.Verticies[1] , y2.Verticies[2])
sigma=dict([ ("12"[i],y2.Verticies[i]) for i in range(2)])
y2=Flag(y2.Verticies,y2.Edges,sigma)
print(y2.Verticies,y2.Edges)


V = [Vertex(name="v"+str(i)) for i in range(1,4)]
y3 = Graph(V)
y3.add_edge(y3.Verticies[0] , y3.Verticies[2])
sigma=dict([ ("12"[i],y3.Verticies[i]) for i in range(2)])
y3=Flag(y3.Verticies,y3.Edges,sigma)
print(y3.Verticies,y3.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
y4 = Graph(V)
y4.add_edge(y4.Verticies[0] , y4.Verticies[2])
y4.add_edge(y4.Verticies[1] , y4.Verticies[2])
sigma=dict([ ("12"[i],y4.Verticies[i]) for i in range(2)])
y4=Flag(y4.Verticies,y4.Edges,sigma)
print(y4.Verticies,y4.Edges)


for i in range(len(Graphs)):
    G=Graphs[i]
    mm="e{} = 1/840 *( {} ".format(i,round(subcube_edge_density(G,3)*840))
    # print("Density of C4 in G{} is:".format(i+1),induced_homomorphism_density(C4,G)*840)
    for F1_index,F2_index in itertools.combinations_with_replacement(range(4),2):
        # print("F"+str(F1_index+1),"F"+str(F2_index+1))
        F1= [f1,f2,f3,f4][F1_index]
        F2= [f1,f2,f3,f4][F2_index]
        if E_theta(F1,F2,G)!=0.0 or False:
            if F1 != F2:
                # print(round(840*2*E_theta(F1,F2,G)),"p{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1))
                mm+=" + {2} p{0}{1} ".format(F1_index+1,F2_index+1,round(840*2*E_theta(F1,F2,G)))
            else:
                # print(round(840*E_theta(F1,F2,G)),"p{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )
                mm+=" + {2} p{0}{1} ".format(F1_index+1,F2_index+1,round(840*E_theta(F1,F2,G)))

    for F1_index,F2_index in itertools.combinations_with_replacement(range(4),2):
        # print("F"+str(F1_index+1),"F"+str(F2_index+1))
        F1= [y1,y2,y3,y4][F1_index]
        F2= [y1,y2,y3,y4][F2_index]
        if E_theta(F1,F2,G)!=0.0 or False:
            if F1 != F2:
                # print(round(840*2*E_theta(F1,F2,G)),"p{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1))
                mm+=' + '+str(round(840*2*E_theta(F1,F2,G)) )+"q{0}{1} ".format(F1_index+1,F2_index+1)
            else:
                # print(round(840*E_theta(F1,F2,G)),"p{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )
                mm+=' + '+str(round(840*E_theta(F1,F2,G)) )+"q{0}{1} ".format(F1_index+1,F2_index+1)
    mm+=');'
    print(mm)
# s=""
# for i in range(75):
#     s+='e{}'.format(i)
# print(s)
        