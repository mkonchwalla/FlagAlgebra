
from main import *

import time
start_time = time.time()

Graphs=[]
C5=generate_cycle_graph(5)
C3=generate_cycle_graph(3)

print('Importing Graphs')
with open('g7_c3c5free.txt','r') as f:
    for line in f:
        x=line.strip('\n').split(';')
        x_v=x[1]
        l=x_v.replace('v','')
        l=eval(l)
        n=7
        V = [Vertex(name="v"+str(i)) for i in range(1,n+1)]
        G=Graph(V)
        if l!=[]:
            for e in l:
                G.add_edge(V[e[0]-1],V[e[1]-1])
        Graphs.append(G)
print(len(Graphs))
C7 = generate_cycle_graph(7)

print("""
Flags - sigma 0
""")
F_2=[]
n=5
with open('flag_5_3_2.txt','r') as f:
    for line in f:
        V = [Vertex(name="v"+str(i)) for i in range(1,n+1)]
        x=line.strip('\n').replace('][',']xxx[').split('xxx')
        x_v=x[1]
        l=x_v.replace('v','')
        l=l.replace('a','1').replace('b','2').replace('c','3')
        l=eval(l)
        sigma={'a':V[0],'b':V[1],'c':V[2]}
        F=Flag(V,sigma=sigma)
        if l!=[]:
            for e in l:
                F.add_edge(V[e[0]-1],V[e[1]-1])
        F_2.append(F)

output = open('c7_2.txt','w')
for i in range(len(Graphs)):
    start_time = time.time()
    G=Graphs[i]
    output.write(str(G.Edges)+'\n')
    print("Density of C7 in G{} is:".format(i+1),induced_homomorphism_density(C7,G)*210)
    for F1_index,F2_index in itertools.combinations_with_replacement(range(len(F_2)),2):
        # print("F"+str(F1_index+1),"F"+str(F2_index+1))
        F1= F_2[F1_index]
        F2= F_2[F2_index]
        if E_theta(F1,F2,G)!=0.0 or False:
            if F1 != F2:
                print(210*2*E_theta(F1,F2,G),"r_{0},{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )
                output.write( str(210*2*E_theta(F1,F2,G))  +'_r_{0},{1}_G{2}\n'.format(F1_index+1,F2_index+1,i+1))
            else:
                print(210*E_theta(F1,F2,G),"r_{0},{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )
                output.write( str(210*E_theta(F1,F2,G))  +'_r_{0},{1}_G{2}\n'.format(F1_index+1,F2_index+1,i+1))
    print(time.time()-start_time)
    print('\n')
output.close()

