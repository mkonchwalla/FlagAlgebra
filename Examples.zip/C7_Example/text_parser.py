i=0
dc={}
from main import *

C7 = generate_cycle_graph(7)

Graphs=[]
print('Importing Graphs')
with open('g7_c3c5free.txt','r') as f:
    for line in f:
        x=line.strip('\n').split(';')
        x_v=x[1]
        l=x_v.replace('v','')
        l=eval(l)
        n=7
        V = [Vertex(name="v"+str(i)) for i in range(1,n+1)]
        G=Graph(V)
        if l!=[]:
            for e in l:
                G.add_edge(V[e[0]-1],V[e[1]-1])
        Graphs.append(G)

f = open('c7_0.txt','r')
i=0
for line in f:
    if line[0]=='[':
        i+=1     
    else:
        line=line.split('_')
        line[0]=int(float(line[0])*3)
        line[2]=line[1]+line[2].replace(',','mm')
        dc.setdefault(i,[]).append((line[0],line[2]))
f.close()

f = open('c7_0_2.txt','r')
i=90
for line in f:
    if line[0]=='[':
        i-=1     
    else:
        line=line.split('_')
        line[0]=int(float(line[0])*3)
        line[2]=line[1]+line[2].replace(',','mm')
        dc.setdefault(i,[]).append((line[0],line[2]))
f.close()

f = open('c7_1.txt','r')
i=0
for line in f:
    if line[0]=='[':
        i+=1     
    else:
        line=line.split('_')
        line[0]=int(float(line[0])*3)
        line[2]=line[1]+line[2].replace(',','mm')
        dc.setdefault(i,[]).append((line[0],line[2]))
f.close()

f = open('c7_2.txt','r')
i=0
for line in f:
    if line[0]=='[':
        i+=1     
    else:
        line=line.split('_')
        line[0]=int(float(line[0])*3)
        line[2]=line[1]+line[2].replace(',','mm')
        dc.setdefault(i,[]).append((line[0],line[2]))
f.close()

s=''
f=open('output2.txt','w')
for i in range(1,90):
    G=Graphs[i-1]
    if i in dc.keys():
        s= 'e{} = 1/630 ( {}'.format(i,induced_homomorphism_density(C7,G))
        for l in dc[i]:
            s+= '+ {} {} '.format(l[0],l[1])
        s+= ');\n'
    f.write(s)
f.close()