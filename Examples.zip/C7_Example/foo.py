# f = open('c7_0.txt','r')
# dc={}
# i=0
# for line in f:
#     if line[0]=='[':
#         i+=1     
#     else:
#         line=line.split('_')
#         line[0]=int(float(line[0])*3)
#         line[2]=line[1]+line[2].replace(',','')
#         dc.setdefault(i,[]).append((line[0],line[2]))
# f.close()

# f = open('c7_0_2.txt','r')
# i=0
# for line in f:
#     if line[0]=='[':
#         i+=1     
#     else:
#         line=line.split('_')
#         line[0]=int(float(line[0])*3)
#         line[2]=line[1]+line[2].replace(',','')
#         dc.setdefault(i,[]).append((line[0],line[2]))
# f.close()
# print(dc[7])
# n=32
# with open('matrix.txt','w') as f:
#     s='Q={ {'
#     for i in range(n):
#         for j in range(n):
#             if i <=j:
#                 s+= ' q{}mm{}'.format(i+1,j+1)
#             else:
#                 s+= ' q{}mm{}'.format(j+1,i+1)
#             if j !=n-1:
#                 s+=','
#         if i!= n-1:
#             s+= '},{'    
#     s+='} };\n'
#     f.write(s)
# print(s)

s=''
for i in range(1,90):
    s+=' e{}≤d,'.format(i)
print(s)