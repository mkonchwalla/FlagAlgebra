from main import * 


V = [Vertex(name="v"+str(i)) for i in range(1,3)]
f1 = Graph(V)
sigma=dict([ ("ab"[i],f1.Verticies[i]) for i in range(1)])
f1=Flag(f1.Verticies,f1.Edges,sigma)
print(f1.Verticies,f1.Edges)
f2 = generate_complete_graph(2)
sigma=dict([ ("ab"[i],f2.Verticies[i]) for i in range(1)])
f2=Flag(f2.Verticies,f2.Edges,sigma)
print(f2.Verticies,f2.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
G1 = Graph(V)

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
G2 = Graph(V)
G2.add_edge(G2.Verticies[0], G2.Verticies[1])

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
G3 = Graph(V)
G3.add_edge(G3.Verticies[0], G3.Verticies[1])
G3.add_edge(G3.Verticies[1], G3.Verticies[2])

for F1,F2 in itertools.combinations_with_replacement([f1,f2],2):
    if F1 != F2: 
        print(2*E_theta(F1,F2,G1))
        print(2*E_theta(F1,F2,G2))
        print(2*E_theta(F1,F2,G3))
        print("\n")
    else: 
        print(E_theta(F1,F2,G1))
        print(E_theta(F1,F2,G2))
        print(E_theta(F1,F2,G3))
        print("\n")