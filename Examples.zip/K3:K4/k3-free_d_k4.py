from main import *


print("Flags - sigma 0")

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
f1 = Graph(V)
sigma=dict([ ("123"[i],f1.Verticies[i]) for i in range(3)])
f1=Flag(f1.Verticies,f1.Edges,sigma)
print("f1",f1.Verticies,f1.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
f2 = Graph(V)
sigma=dict([ ("123"[i],f2.Verticies[i]) for i in range(3)])
f2.add_edge(V[0],V[3])
f2=Flag(f2.Verticies,f2.Edges,sigma)
print("f2",f2.Verticies,f2.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
f3 = Graph(V)
sigma=dict([ ("123"[i],f3.Verticies[i]) for i in range(3)])
f3.add_edge(V[1],V[3])
f3=Flag(f3.Verticies,f3.Edges,sigma)
print("f3",f3.Verticies,f3.Edges)


V = [Vertex(name="v"+str(i)) for i in range(1,5)]
f4 = Graph(V)
sigma=dict([ ("123"[i],f4.Verticies[i]) for i in range(3)])
f4.add_edge(V[0],V[3])
f4.add_edge(V[1],V[3])
f4=Flag(f4.Verticies,f4.Edges,sigma)
print("f4",f4.Verticies,f4.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
f5 = Graph(V)
sigma=dict([ ("123"[i],f5.Verticies[i]) for i in range(3)])
f5.add_edge(V[2],V[3])
f5=Flag(f5.Verticies,f5.Edges,sigma)
print("f5",f5.Verticies,f5.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
f6 = Graph(V)
sigma=dict([ ("123"[i],f6.Verticies[i]) for i in range(3)])
f6.add_edge(V[0],V[3])
f6.add_edge(V[2],V[3])
f6=Flag(f6.Verticies,f6.Edges,sigma)
print("f6",f6.Verticies,f6.Edges)


V = [Vertex(name="v"+str(i)) for i in range(1,5)]
f7 = Graph(V)
sigma=dict([ ("123"[i],f7.Verticies[i]) for i in range(3)])
f7.add_edge(V[1],V[3])
f7.add_edge(V[2],V[3])
f7=Flag(f7.Verticies,f7.Edges,sigma)
print("f7",f7.Verticies,f7.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
f8 = Graph(V)
sigma=dict([ ("123"[i],f8.Verticies[i]) for i in range(3)])
f8.add_edge(V[0],V[3])
f8.add_edge(V[2],V[3])
f8.add_edge(V[1],V[3])
f8=Flag(f8.Verticies,f8.Edges,sigma)
print("f8",f8.Verticies,f8.Edges)



print("Flags - sigma 1")

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
y1 = Graph(V)
sigma=dict([ ("123"[i],y1.Verticies[i]) for i in range(3)])
y1.add_edge(V[0],V[1])
y1=Flag(y1.Verticies,y1.Edges,sigma)
print("Y1",y1.Verticies,y1.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
y2 = Graph(V)
sigma=dict([ ("123"[i],y2.Verticies[i]) for i in range(3)])
y2.add_edge(V[0],V[3])
y2.add_edge(V[0],V[1])
y2=Flag(y2.Verticies,y2.Edges,sigma)
print("Y2",y2.Verticies,y2.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
y3 = Graph(V)
sigma=dict([ ("123"[i],y3.Verticies[i]) for i in range(3)])
y3.add_edge(V[1],V[3])
y3.add_edge(V[0],V[1])
y3=Flag(y3.Verticies,y3.Edges,sigma)
print("Y3",y3.Verticies,y3.Edges)


V = [Vertex(name="v"+str(i)) for i in range(1,5)]
y4 = Graph(V)
sigma=dict([ ("123"[i],y4.Verticies[i]) for i in range(3)])
y4.add_edge(V[2],V[3])
y4.add_edge(V[0],V[1])
y4=Flag(y4.Verticies,y4.Edges,sigma)
print("Y4",y4.Verticies,y4.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
y5 = Graph(V)
sigma=dict([ ("123"[i],y5.Verticies[i]) for i in range(3)])
y5.add_edge(V[0],V[3])
y5.add_edge(V[2],V[3])
y5.add_edge(V[0],V[1])
y5=Flag(y5.Verticies,y5.Edges,sigma)
print("Y5",y5.Verticies,y5.Edges)


V = [Vertex(name="v"+str(i)) for i in range(1,5)]
y6 = Graph(V)
sigma=dict([ ("123"[i],y6.Verticies[i]) for i in range(3)])
y6.add_edge(V[1],V[3])
y6.add_edge(V[2],V[3])
y6.add_edge(V[0],V[1])
y6=Flag(y6.Verticies,y6.Edges,sigma)
print("Y6",y6.Verticies,y6.Edges)

print(
"""
Flags -- Sigma 2
""")

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
z1 = Graph(V)
sigma=dict([ ("123"[i],z1.Verticies[i]) for i in range(3)])
z1.add_edge(V[0],V[1])
z1.add_edge(V[1],V[2])
z1=Flag(z1.Verticies,z1.Edges,sigma)
print("Z1",z1.Verticies,z1.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
z2 = Graph(V)
sigma=dict([ ("123"[i],z2.Verticies[i]) for i in range(3)])
z2.add_edge(V[0],V[3])
z2.add_edge(V[0],V[1])
z2.add_edge(V[1],V[2])
z2=Flag(z2.Verticies,z2.Edges,sigma)
print("Z2",z2.Verticies,z2.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
z3 = Graph(V)
sigma=dict([ ("123"[i],z3.Verticies[i]) for i in range(3)])
z3.add_edge(V[1],V[3])
z3.add_edge(V[0],V[1])
z3.add_edge(V[1],V[2])
z3=Flag(z3.Verticies,z3.Edges,sigma)
print("Z3",z3.Verticies,z3.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
z4 = Graph(V)
sigma=dict([ ("123"[i],z4.Verticies[i]) for i in range(3)])
z4.add_edge(V[2],V[3])
z4.add_edge(V[0],V[1])
z4.add_edge(V[1],V[2])
z4=Flag(z4.Verticies,z4.Edges,sigma)
print("Z4",z4.Verticies,z4.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
z5 = Graph(V)
sigma=dict([ ("123"[i],z5.Verticies[i]) for i in range(3)])
z5.add_edge(V[0],V[3])
z5.add_edge(V[2],V[3])
z5.add_edge(V[0],V[1])
z5.add_edge(V[1],V[2])
z5=Flag(z5.Verticies,z5.Edges,sigma)
print("Z5",z5.Verticies,z5.Edges)
print("\n")


for i in range(14):
    G=G_list[i]
    print("Density of C5 in G{} is:".format(i+1),induced_homomorphism_density(C5,G)*120)
    for F1_index,F2_index in itertools.combinations_with_replacement(range(8),2):
        # print("F"+str(F1_index+1),"F"+str(F2_index+1))
        F1= [f1,f2,f3,f4,f5,f6,f7,f8][F1_index]
        F2= [f1,f2,f3,f4,f5,f6,f7,f8][F2_index]

        if E_theta(F1,F2,G)!=0.0 or False:
            if F1 != F2:
                print(120*2*E_theta(F1,F2,G),"p{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )

            else:
                print(120*E_theta(F1,F2,G),"p{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )

    for F1_index,F2_index in itertools.combinations_with_replacement(range(6),2):
        # print("F"+str(F1_index+1),"F"+str(F2_index+1))
        F1= [y1,y2,y3,y4,y5,y6][F1_index]
        F2= [y1,y2,y3,y4,y5,y6][F2_index]

        if E_theta(F1,F2,G)!=0.0 or False:
            if F1 != F2:
                print(120*2*E_theta(F1,F2,G),"q{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )

            else:
                print(120*E_theta(F1,F2,G),"q{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )

    for F1_index,F2_index in itertools.combinations_with_replacement(range(5),2):
        # print("F"+str(F1_index+1),"F"+str(F2_index+1))
        F1= [z1,z2,z3,z4,z5][F1_index]
        F2= [z1,z2,z3,z4,z5][F2_index]

        if E_theta(F1,F2,G)!=0.0 or False:
            if F1 != F2:
                print(120*2*E_theta(F1,F2,G),"r{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )

            else:
                print(120*E_theta(F1,F2,G),"r{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )
    print("\n")

print("Executed in --- %s seconds ---" % (time.time() - start_time))
