from main import * 


V = [Vertex(name="v"+str(i)) for i in range(1,3)]
f1 = Graph(V)
sigma=dict([ ("ab"[i],f1.Verticies[i]) for i in range(1)])
f1=Flag(f1.Verticies,f1.Edges,sigma)
print(f1.Verticies,f1.Edges)
f2 = generate_complete_graph(2)
sigma=dict([ ("ab"[i],f2.Verticies[i]) for i in range(1)])
f2=Flag(f2.Verticies,f2.Edges,sigma)
print(f2.Verticies,f2.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G1 = Graph(V)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G2 = Graph(V)
G2.add_edge(G2.Verticies[0], G2.Verticies[1])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G3 = Graph(V)
G3.add_edge(G3.Verticies[0], G3.Verticies[1])
G3.add_edge(G3.Verticies[1], G3.Verticies[2])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G4 = Graph(V)
G4.add_edge(G4.Verticies[0], G4.Verticies[1])
G4.add_edge(G4.Verticies[2], G4.Verticies[3])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G5 = Graph(V)
G5.add_edge(G5.Verticies[0], G5.Verticies[1])
G5.add_edge(G5.Verticies[1], G5.Verticies[2])
G5.add_edge(G5.Verticies[0], G5.Verticies[2])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G6 = Graph(V)
G6.add_edge(G6.Verticies[0], G6.Verticies[1])
G6.add_edge(G6.Verticies[0], G6.Verticies[2])
G6.add_edge(G6.Verticies[0],G6.Verticies[3])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G7 = Graph(V)
G7.add_edge(G7.Verticies[0], G7.Verticies[1])
G7.add_edge(G7.Verticies[0], G7.Verticies[2])
G7.add_edge(G7.Verticies[2],G7.Verticies[3])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G8 = Graph(V)
G8.add_edge(G8.Verticies[0], G8.Verticies[1])
G8.add_edge(G8.Verticies[0], G8.Verticies[2])
G8.add_edge(G8.Verticies[0],G8.Verticies[3])
G8.add_edge(G8.Verticies[1],G8.Verticies[3])

G9 = generate_cycle_graph(4)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G10 = Graph(V)
G10.add_edge(G10.Verticies[0], G10.Verticies[1])
G10.add_edge(G10.Verticies[0], G10.Verticies[2])
G10.add_edge(G10.Verticies[0],G10.Verticies[3])
G10.add_edge(G10.Verticies[1],G10.Verticies[3])
G10.add_edge(G10.Verticies[1],G10.Verticies[2])


for F1,F2 in itertools.combinations_with_replacement([f2,f1],2):
    if F1 != F2: 
        print(2*E_theta(F1,F2,G1))
        print(2*E_theta(F1,F2,G2))
        print(2*E_theta(F1,F2,G3))
        print(2*E_theta(F1,F2,G4))
        print(2*E_theta(F1,F2,G5))
        print(2*E_theta(F1,F2,G6))
        print(2*E_theta(F1,F2,G7))
        print(2*E_theta(F1,F2,G8))
        print(2*E_theta(F1,F2,G9))
        print(2*E_theta(F1,F2,G10))
        print("\n")
    else: 
        print(E_theta(F1,F2,G1))
        print(E_theta(F1,F2,G2))
        print(E_theta(F1,F2,G3))
        print(E_theta(F1,F2,G4))
        print(E_theta(F1,F2,G5))
        print(E_theta(F1,F2,G6))
        print(E_theta(F1,F2,G7))
        print(E_theta(F1,F2,G8))
        print(E_theta(F1,F2,G9))
        print(E_theta(F1,F2,G10))
        print("\n")