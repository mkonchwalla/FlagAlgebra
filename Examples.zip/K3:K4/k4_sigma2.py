from main import * 
"""
Creating Graphs
"""
K3 = generate_complete_graph(3)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G1 = Graph(V)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G2 = Graph(V)
G2.add_edge(G2.Verticies[0], G2.Verticies[1])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G3 = Graph(V)
G3.add_edge(G3.Verticies[0], G3.Verticies[1])
G3.add_edge(G3.Verticies[1], G3.Verticies[2])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G4 = Graph(V)
G4.add_edge(G4.Verticies[0], G4.Verticies[1])
G4.add_edge(G4.Verticies[2], G4.Verticies[3])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G5 = Graph(V)
G5.add_edge(G5.Verticies[0], G5.Verticies[1])
G5.add_edge(G5.Verticies[1], G5.Verticies[2])
G5.add_edge(G5.Verticies[0], G5.Verticies[2])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G6 = Graph(V)
G6.add_edge(G6.Verticies[0], G6.Verticies[1])
G6.add_edge(G6.Verticies[0], G6.Verticies[2])
G6.add_edge(G6.Verticies[0],G6.Verticies[3])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G7 = Graph(V)
G7.add_edge(G7.Verticies[0], G7.Verticies[1])
G7.add_edge(G7.Verticies[0], G7.Verticies[2])
G7.add_edge(G7.Verticies[2],G7.Verticies[3])

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G8 = Graph(V)
G8.add_edge(G8.Verticies[0], G8.Verticies[1])
G8.add_edge(G8.Verticies[0], G8.Verticies[2])
G8.add_edge(G8.Verticies[0],G8.Verticies[3])
G8.add_edge(G8.Verticies[1],G8.Verticies[3])

G9 = generate_cycle_graph(4)

V = [Vertex(name="v"+str(i)) for i in range(1,5)]
G10 = Graph(V)
G10.add_edge(G10.Verticies[0], G10.Verticies[1])
G10.add_edge(G10.Verticies[0], G10.Verticies[2])
G10.add_edge(G10.Verticies[0],G10.Verticies[3])
G10.add_edge(G10.Verticies[1],G10.Verticies[3])
G10.add_edge(G10.Verticies[1],G10.Verticies[2])

"""
Creating Flags 
"""

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
f1 = Graph(V)
f1.add_edge(f1.Verticies[0] , f1.Verticies[1])
sigma=dict([ ("12"[i],f1.Verticies[i]) for i in range(2)])
f1=Flag(f1.Verticies,f1.Edges,sigma)
print(f1.Verticies,f1.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
f2 = Graph(V)
f2.add_edge(f2.Verticies[0] , f2.Verticies[1])
f2.add_edge(f2.Verticies[1] , f2.Verticies[2])
sigma=dict([ ("12"[i],f2.Verticies[i]) for i in range(2)])
f2=Flag(f2.Verticies,f2.Edges,sigma)
print(f2.Verticies,f2.Edges)


V = [Vertex(name="v"+str(i)) for i in range(1,4)]
f3 = Graph(V)
f3.add_edge(f3.Verticies[0] , f3.Verticies[1])
f3.add_edge(f3.Verticies[0] , f3.Verticies[2])
sigma=dict([ ("12"[i],f3.Verticies[i]) for i in range(2)])
f3=Flag(f3.Verticies,f3.Edges,sigma)
print(f3.Verticies,f3.Edges)

f4 = generate_complete_graph(3)
sigma=dict([ ("12"[i],f4.Verticies[i]) for i in range(2)])
f4=Flag(f4.Verticies,f4.Edges,sigma)
print(f4.Verticies,f4.Edges)


V = [Vertex(name="v"+str(i)) for i in range(1,4)]
y1 = Graph(V)
sigma=dict([ ("12"[i],y1.Verticies[i]) for i in range(2)])
y1=Flag(y1.Verticies,y1.Edges,sigma)
print(y1.Verticies,y1.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
y2 = Graph(V)
y2.add_edge(y2.Verticies[1] , y2.Verticies[2])
sigma=dict([ ("12"[i],y2.Verticies[i]) for i in range(2)])
y2=Flag(y2.Verticies,y2.Edges,sigma)
print(y2.Verticies,y2.Edges)


V = [Vertex(name="v"+str(i)) for i in range(1,4)]
y3 = Graph(V)
y3.add_edge(y3.Verticies[0] , y3.Verticies[2])
sigma=dict([ ("12"[i],y3.Verticies[i]) for i in range(2)])
y3=Flag(y3.Verticies,y3.Edges,sigma)
print(y3.Verticies,y3.Edges)

V = [Vertex(name="v"+str(i)) for i in range(1,4)]
y4 = Graph(V)
y4.add_edge(y4.Verticies[0] , y4.Verticies[2])
y4.add_edge(y4.Verticies[1] , y4.Verticies[2])
sigma=dict([ ("12"[i],y4.Verticies[i]) for i in range(2)])
y4=Flag(y4.Verticies,y4.Edges,sigma)
print(y4.Verticies,y4.Edges)

G_list = [G1,G2,G3,G4,G5,G6,G7,G8,G9,G10]

print("Starting Computation")
for i in  range(len(G_list)):
    G=G_list[i]
    print('G{}: {}'.format(i+1,G))
    print("Density of K3 in G{} is:".format(i+1),induced_homomorphism_density(K3,G))
    for F1_index,F2_index in itertools.combinations_with_replacement(range(4),2):
        # print("F"+str(F1_index+1),"F"+str(F2_index+1))
        F1= [f1,f2,f3,f4][F1_index]
        F2= [f1,f2,f3,f4][F2_index]
        if E_theta(F1,F2,G)!=0.0:
            if F1 != F2: 
                print(12*2*E_theta(F1,F2,G),"q{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )
            else: 
                print(12*E_theta(F1,F2,G),"q{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )
    for F1_index,F2_index in itertools.combinations_with_replacement(range(4),2):
        # print("F"+str(F1_index+1),"F"+str(F2_index+1))
        F1= [y1,y2,y3,y4][F1_index]
        F2= [y1,y2,y3,y4][F2_index]
        if E_theta(F1,F2,G)!=0.0:
            if F1 != F2: 
                print(12*2*E_theta(F1,F2,G),"p{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )
            else: 
                print(12*E_theta(F1,F2,G),"p{0}{1} in graph G{2}".format(F1_index+1,F2_index+1,i+1) )
    print("\n")