
from datetime import datetime

outfile=open("log.txt","a")

text= ''':

Done!


'''

outfile.write("\nNew log entry - Date and time is " + str(datetime.now()) +  text + "\n\n\n")
outfile.close()